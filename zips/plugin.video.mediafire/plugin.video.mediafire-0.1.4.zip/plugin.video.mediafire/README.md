MediaFire for KODI / XBMC
=========================

A MediaFire Video/Music add-on for Kodi / XBMC
