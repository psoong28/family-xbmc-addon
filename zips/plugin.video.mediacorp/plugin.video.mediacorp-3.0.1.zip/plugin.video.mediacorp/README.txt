plugin.video.mediacorp
================

Kodi Addon for mediacorp
For Kodi Isgengard and later releases

V3.0.1 Isengard version 
V2.0.1 initial v2 release

