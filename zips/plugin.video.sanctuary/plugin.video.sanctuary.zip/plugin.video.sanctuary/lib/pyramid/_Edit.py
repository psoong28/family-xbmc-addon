import xbmcaddon

MainBase = 'http://tombraiderbuilds.co.uk/addon/home.txt'
addon = xbmcaddon.Addon('plugin.video.sanctuary')