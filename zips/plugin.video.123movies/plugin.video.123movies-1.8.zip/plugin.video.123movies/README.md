Video Plugin for Kodi to Watch VOD from http://123movies.to/
Thanks To the original author for the his addon which this new addon is based on.
Original Addon = Dramaonline; Original Author : Aresu  

